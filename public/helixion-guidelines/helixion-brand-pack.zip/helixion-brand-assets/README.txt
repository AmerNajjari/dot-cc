Helixion brand assets, v0.1 (2026-10-29). A proposal until the founders agree.

logos/          wordmark for dark and light grounds, one-colour white and night, the X alone, the app icon (SVG; PNG when rendered)
motif/          the Helix: plain, with the amber disagreement rung, and animated (turns once every 4 s)
icons/white/    16 interface icons in white, 24 px grid, 1.8 px stroke, round ends, for dark grounds
icons/color/    the same 16 on solid tiles in their role colour (SVG and PNG); navigation icons sit on violet
tokens.css      colours, type, spacing, motion, both themes
app-prototype/  the clickable app. Start at auth.html (sign in or create an account), then inbox, queue, Brand DNA and the 33-service marketing menu. It reads ../tokens.css and ../assets/

The guideline: helixion-brand-system.html. Never redraw or retype the wordmark; use these files.
